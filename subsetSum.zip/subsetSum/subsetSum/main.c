#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<stdbool.h>
int subset(int myarr[],int n,int sum)
{
    int f[sum+1],m=0,row,col,k,num,count=0;
    for(row=1;row<=sum;row++)
    {
        f[row]=0;f[0]=1;
    }
    for(row=0;row<n;row++)
    {
        num=myarr[row];
        if(num>sum)continue;
        m=m+num>sum?sum:m+num;
        for(k=m-num,col=m;k>=0;col--,k--)
        {
            if(f[k])
            {
                 f[col]=num;

            }
        }
        if(!f[sum])continue;
        k=sum;
        printf("%s","{");
        while(k){
            
           

            printf("%d ",f[k]);
            
            k-=f[k];
            if(k>0)
            {
             printf("%s"," , ");
            }
        }
        printf("%s","}");
        printf("%s\n","");
        //exit(0);
            count++;
    }

    if(count==0)
    {
        printf("no subset found\n");
    }
    else
    {
        printf("subset found\n");
    }
    return count;
}
void remove_crlf(char *s)
{
   char *t = s + strlen(s);
   t--;

   while((t >= s) && (*t == '\n' || *t == '\r'))
   {
       *t = '\0';
       t--;

      
   }
}

int get_next_nonblank_line(FILE *ifp, char *buf, int max_length)
{
   buf[0] = '\0';

   while(!feof(ifp) && (buf[0] == '\0'))
   {
       fgets(buf, max_length, ifp);
       remove_crlf(buf);
   }

   if(buf[0] != '\0')
   {
       return 1;
   }
   else
   {
       return 0;
   }
}


int main(){
    int choice;
    printf("hello, enter 1) keyboard input 2) file \n");
    scanf("%i",&choice);
    if(choice==1)
    {
        int size;
        printf("%s","Enter the number of elements: ");
        scanf("%i",&size);
        int set[size];
        printf("%s","Enter the elements: ");
        for(int index=0;index<size;index++)
        {
            scanf("%i",&set[index]);
        }
        int sum;
        printf("%s","Enter the targeted sum: ");
        scanf("%i",&sum);
        return subset(set,size,sum);
    }
    if(choice==2)
    {
        int c;
        printf("%s","Now press 3 for sum1, 4 for sum2");
        scanf("%i",&c);
        if(c==3)
        {
        int size = 0;
        int sum = 0;
        int sum2;
        int target;
        char buffer[100];
        FILE *fptr;
        fptr=fopen("lab3.a.dat.txt","r");

        for (int index = 0; index < 1; index++)
               {
                   

                   //storing in data members
                   get_next_nonblank_line(fptr, buffer, 100);
                   remove_crlf(buffer);
                   sscanf(buffer, "%d%d%d  ", &size, &sum, &sum2);
                   printf("%s","size: ");
                   printf("%i", size);
                   printf("\n");
                   printf("%s","sum: ");
                   printf("%i", sum);
                   printf("\n");

                      
                  

           }
   
         int set[size];
        for (int index = 0; index < size; index++)
        {
            get_next_nonblank_line(fptr, buffer, 100);
            remove_crlf(buffer);

            //storing in data members
            sscanf(buffer, "%i  ", &target);
            
                set[index]=target;
            printf("%s","target: ");
            printf("%i", set[index]);
            printf("\n");
 

    }
        return subset(set,size,sum);
        
        }
    
    if(c==4)
    {
           int size = 0;
               int sum = 0;
               int sum2;
               int target;
               char buffer[100];
               FILE *fptr;
               fptr=fopen("lab3.a.dat.txt","r");

               for (int index = 0; index < 1; index++)
                      {
                          

                          //storing in data members
                          get_next_nonblank_line(fptr, buffer, 100);
                          remove_crlf(buffer);
                          sscanf(buffer, "%d%d%d  ", &size, &sum, &sum2);
                          printf("%s","size: ");
                          printf("%i", size);
                          printf("\n");
                          printf("%s","sum: ");
                          printf("%i", sum2);
                          printf("\n");

                             
                         

                  }
          
                int set[size];
               for (int index = 0; index < size; index++)
               {
                   get_next_nonblank_line(fptr, buffer, 100);
                   remove_crlf(buffer);

                   //storing in data members
                   sscanf(buffer, "%i  ", &target);
                   
                       set[index]=target;
                   printf("%s","target: ");
                   printf("%i", set[index]);
                   printf("\n");
        

           }
               return subset(set,size,sum2);
               
               
    }
   
    }
  
  
}


