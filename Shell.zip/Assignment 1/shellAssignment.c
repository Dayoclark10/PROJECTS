/*
Oluwaseetofunmi Komolafe
1001937963
CSE 3320
Lab 1:
A text based shell utility that mimics Unix.
Prototype given by the professor
*/

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <time.h>

#define fileOrDirectoryMax 1024
#define maxChars 2048
void filePrinter(struct dirent *directoryInfo, DIR *directory, char itemList[][maxChars], char userChoice); // List all files in current direcroty
void directoryPrinter(struct dirent *directoryInfo, DIR *directory, char itemList[fileOrDirectoryMax][maxChars]);                                        // Lists all sudirectory in current directory
void operationsMenu();                                                                                      // Shows user the available options
void operationStarter(char userChoice, char directoryPath[maxChars], char command[256], char choice[5]);    // Begins the user chosen operation

int main(void)
{
    DIR *directory;
    struct dirent *directoryInfo;
    char directoryPath[maxChars], command[256], instruction[maxChars], choice[5];
    time_t currentTime;
    char userChoice;
    char itemList[fileOrDirectoryMax][maxChars];

    while (!(userChoice == 'Q'))
    {
        getcwd(directoryPath, maxChars);
        currentTime = time(NULL);

        printf("\n---START---\n");

        printf("The current working directory is: %s\n", directoryPath);
        printf("The current date and time is: %s\n", ctime(&currentTime));

        directory = opendir(".");

        if (directory == NULL)
        {
            printf("Directory can not be opened");
            return 0;
        }

        filePrinter(directoryInfo, directory, itemList, userChoice);

        rewinddir(directory);

        directoryPrinter(directoryInfo, directory, itemList);

        operationsMenu();

        while ((userChoice = getchar()) != EOF && userChoice != '\n') // Prevents loop from running twice

        operationStarter(userChoice, directoryPath, command, choice);
    }

    closedir(directory);
    return 0;
}

void filePrinter(struct dirent *directoryInfo, DIR *directory, char itemList[fileOrDirectoryMax][maxChars], char userChoice)
{
    int k, i = 0, fileCount = 0, n = 5, p = -5;
    int navigator = 1;
    printf("FILES: \n");
    while ((directoryInfo = readdir(directory)))
    {
        // Check that type is a regular file then displays
        if ((directoryInfo->d_type) & DT_REG)
        {
            strcpy(itemList[i], directoryInfo->d_name);
            printf("\t%d. %s \n", i, itemList[i]);
            i++;
        }
    }

    // N and P causing bug

    // fileCount = i;
    // for (i = 0; i < 5; i++)
    // {
    //     if (i >= fileCount)
    //     {
    //         printf("All files displayed");
    //         break;
    //     }
    //     else
    //     {
    //         printf("\t%d. %s \n", i, itemList[i]);
    //     }
    // }
    // if (fileCount > 5)
    // {
    //     printf("\nPress N to see more files\n");
    //     userChoice = getchar();
    //     while (userChoice == 'N' || userChoice == 'P')
    //     {
    //         if (userChoice == 'N')
    //         {
    //             navigator++;
                
    //             for (i = i; i < navigator * n; i++)
    //             {
    //                 //printf("%d   ", navigator);
    //                 if (i >= fileCount)
    //                 {
    //                     break;
    //                 }
    //                 else
    //                 {
    //                     printf("\t%d. %s \n", i, itemList[i]);
    //                 }
    //             }
    //         }
    //         else if (userChoice == 'P')
    //         {
    //             navigator--;
    //             for (i = i - n; i < navigator * n; i++)
    //             {
    //                 if (i >= fileCount)
    //                 {
    //                     break;
    //                 }
    //                 else
    //                 {
    //                     printf("\t%d. %s \n", i, itemList[i]);
    //                 }
    //             }
    //         }
    //         else
    //         {
    //             printf("Please pick one of the two options");
    //         }
    //     }
    // }
}

    void directoryPrinter(struct dirent * directoryInfo, DIR * directory, char itemList[fileOrDirectoryMax][maxChars] )
    {
        int i = 0;
        printf("\nDIRECTORIES: \n");
        while ((directoryInfo = readdir(directory)))
        {
            // Check that type is a directory then displays
            if ((directoryInfo->d_type) & DT_DIR)
            {
                strcpy(itemList[i], directoryInfo->d_name);
                printf("\t%d. %s \n", i, directoryInfo->d_name);
                i++;
            }
        }
    }

    void operationsMenu()
    {
        printf("\nOPERATIONS: \n");
        printf("\tC Change Directory\n\tD Display\n\tE Edit\n\t"
               "R Run\n\tS Sort Directory Listing\n\tQ Quit\n");

        printf("\nSelect an Operation:\n");
    }

    void operationStarter(char userChoice, char directoryPath[maxChars], char command[256], char choice[5])
    {
        int check = 1;
        char execute[maxChars], command2[maxChars], temp[1];
        strcpy(execute, "executable ");

        if (userChoice == 'C' || userChoice == 'c')
        {
            while (!(check == 0))
            {
                printf("Change directory to?: ");
                scanf("%s", command);
                check = chdir(command);

                if (check == 0)
                {
                    chdir(command);
                    return;
                }
                else
                {
                    printf("That is not a valid directory choice. Please try again!\n");
                    // printf("Press Q to return to main menu\n");
                    // scanf("%c", temp);

                    // if (userChoice == 'Q')
                    // {
                    //     check = 0;
                    // }
                }
            }
        }
        else if (userChoice == 'D' || userChoice == 'd')
        {
            printf("Note: Press q to leave display view\n");
            printf("What would you like to display?(Enter filename): ");
            scanf("%s", directoryPath);

            strcpy(command, "less ");
            strcat(command, directoryPath);
            system(command);
        }
        else if (userChoice == 'E' || userChoice == 'e')
        {
            printf("Edit what?: ");
            scanf("%s", directoryPath);

            printf("\nIf file does not exist, a new file will be created");

            strcpy(command, "pico ");
            strcat(command, directoryPath);
            system(command);
        }
        else if (userChoice == 'R' || userChoice == 'r')
        {
            printf("Run what?: ");
            scanf("%s", directoryPath);

            strcpy(command, "gcc -o ");
            strcat(command, execute);
            strcat(command, directoryPath);
            // gcc -o executable filename.extension

            strcpy(command2, "\n./");
            strcat(command2, execute);
            // ./executable

            strcat(command, command2);
            // gcc -o executable filename.extention
            // ./execuable

            system(command);
        }
        else if (userChoice == 'S' || userChoice == 's')
        {
            printf("Type 'date' to sort by date, type 'size' to sort by size): ");
            while (!(0 == strcmp(choice, "size")) || !(0 == strcmp(choice, "date")))
            {
                scanf("%s", choice);

                if (0 == strcmp(choice, "size"))
                {
                    strcpy(command, "du -sh -- *  | sort -rh");

                    system(command);
                    break;
                }
                else if (0 == strcmp(choice, "date"))
                {

                    strcpy(command, "ls -lt");
                    system(command);
                    break;
                }
                else
                {
                    printf("Please sort by either 'date' or 'size'!: ");
                }
            }
        }
        else if (userChoice == 'Q' || userChoice == 'q')
        {
            exit(0);
        }
        else
        {
            printf("Please select of the valid options!");
        }
    }