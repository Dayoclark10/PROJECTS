/*  Some example code and prototype -
    contains many, many problems: should check for return values
    (especially system calls), handle errors, not use fixed paths,
    handle parameters, put comments, watch out for buffer overflows,
    security problems, use environment variables, etc.
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <time.h>

int main(void)
{
  //printf("\n\n\n\n\nYOOOOO WORLDDD\n\n\n\n\n");
  pid_t child;                  // pid_t is a signed integer, used to represent process ID
  DIR *d;                       // pointer to a directory
  struct dirent *directoryInfo; // struct dirent is the structure type used to return info about directory enteries
  int i, c, k;
  char directoryPath[256], cmd[256];
  time_t t; // time data type in C but is in seconds

  // while true (1 is true in C)
  while (1)
  {
    printf("\n---START---\n");
    t = time(NULL); // time is a systems call, time(NULL) returns the seconds elapsed since Jan 1 1970

    printf("Time: %s\n", ctime(&t)); // ctime is a format of time in string

    printf("-----------------------------------------------\n");

    getcwd(directoryPath, 200); // get current working directory string and print 200 characters of that into s
    printf("\nCurrent Directory: %s \n", directoryPath);

    d = opendir(directoryPath); // open the current directory called "." and returns a pointer to a directory

    c = 0;

    while ((directoryInfo = readdir(d))) // read the content of the current working directory and retrieves information
    {
      // d_type to see if it is a sub directory or a file, DT_DIR is a firectory, DT_REG is a regular file
      if ((directoryInfo->d_type) & DT_DIR) // so we will only proceed if it is a directory
        printf(" ( %d Directory:  %s ) \n", c++, directoryInfo->d_name);
    }
    // Systems call, close directory
    closedir(d);
    printf("-----------------------------------------\n");

    d = opendir(".");
    c = 0;
    while ((directoryInfo = readdir(d)))
    {
      if (((directoryInfo->d_type) & DT_REG))
        printf(" ( %d File:  %s ) \n", c++, directoryInfo->d_name);
      if ((c % 5) == 0)
      {
        printf("Hit N for Next\n");

        k = getchar();
      }
    }
    closedir(d);
    printf("-----------------------------------------\n");

    printf("Select: \n'q' to quit\n'e' to edit\n'r' to run and \n'c' to change\n");

    c = getchar();
    getchar();
    switch (c)
    {
    case 'q':
      exit(0); // Quit terminal
    case 'e':
      printf("Edit what?: ");
      scanf("%s", directoryPath);
      strcpy(cmd, "pico "); // linux command to edit
      strcat(cmd, directoryPath);
      system(cmd); // system is a call to the shell that creates another process
      break;
    case 'r':
      printf("Run what?: ");
      scanf("%s", cmd);
      system(cmd);
      break;
    case 'c':
      printf("Change directory to?: ");
      scanf("%s", cmd);
      chdir(cmd); // system( cmd ); system call, change directory
      break;
    }

    printf("===END===\n");
  }
}
