// The MIT License (MIT)
//
// Copyright (c) 2021, 2022 Trevor Bakker
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES UTA OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

#include "mavalloc.h"
#include <stdlib.h>
#define MAX_ALLOCATE_NUM 10000

enum TYPE
{
  H,
  P
};
struct Node
{
  size_t size;
  enum TYPE type;
  void *arena;

  int in_use;
  int next;
  int previous;
};

struct Node list[MAX_ALLOCATE_NUM];
static enum ALGORITHM algorithm;
static void *arena;
static int linked_list_size = 0;

// returns a free node from the array
// to be used for adding a node to the list
static int get_free_node()
{
  for (int i = 0; i < MAX_ALLOCATE_NUM; i++)
  {
    if (!list[i].in_use)
      return i;
  }
  return -1;
}

static int next_fit_last_result = 0;

static int find_next_fit(size_t size)
{
  int start = next_fit_last_result;

  // check if the last allocated node still in use
  // it may have been freed. Otherwise find the next node index tha is in use
  while (start < MAX_ALLOCATE_NUM && !list[start].in_use)
    start++;

  // no node found that are in use after the last next_fit_result index
  // so start from the head
  if (start >= MAX_ALLOCATE_NUM)
    start = 0;

  // update the next_fit_last_result
  // because, in case of no suitable node is found
  // this value will not get updated
  next_fit_last_result = start;

  // start searching from the last allocated node
  int i = start;
  while (i >= 0)
  {
    if (list[i].in_use && list[i].type == H && list[i].size >= size)
    {
      next_fit_last_result = i;
      return i;
    }
    i = list[i].next;
  }

  // start iterating the list from the beginning
  next_fit_last_result = 0;
  i = 0;

  while (i != start)
  {
    if (list[i].in_use && list[i].type == H && list[i].size >= size)
    {
      next_fit_last_result = i;
      return i;
    }
    i = list[i].next;
  }

  return -1;
}

static int find_target_hole(size_t size)
{

  if (algorithm == NEXT_FIT)
    return find_next_fit(size);

  int target = -1;
  int target_size = 0;
  int i = 0;

  while (i != -1)
  {
    if (list[i].in_use && list[i].type == H && list[i].size >= size)
    {
      if (algorithm == BEST_FIT)
      {
        if (target == -1 || list[i].size < target_size)
        {
          target = i;
          target_size = list[i].size;
        }
      }
      else if (algorithm == WORST_FIT)
      {
        if (target == -1 || list[i].size > target_size)
        {
          target = i;
          target_size = list[i].size;
        }
      }
      else if (algorithm == FIRST_FIT)
      {
        target = i;
        break;
      }
    }

    i = list[i].next;
  }
  return target;
}

int mavalloc_init(size_t size, enum ALGORITHM al)
{
  if (size < 0)
    return -1;

  algorithm = al;
  size = ALIGN4(size);
  arena = malloc(size);

  if (arena == NULL)
    return -1;

  for (int i = 0; i < MAX_ALLOCATE_NUM; i++)
  {
    list[i].in_use = 0;
    list[i].next = -1;
    list[i].previous = -1;
  }

  // index 0 will always be the head of the linked list
  list[0].size = size;
  list[0].type = H;
  list[0].arena = arena;
  list[0].in_use = 1;
  list[0].next = -1;
  list[0].previous = -1;

  linked_list_size = 1;
  next_fit_last_result = 0;
  return 0;
}

void mavalloc_destroy()
{
  free(arena);
  arena = NULL;
  linked_list_size = 0;
}

void *mavalloc_alloc(size_t size)
{
  size = ALIGN4(size);
  int free_node = get_free_node();
  if (free_node == -1 || arena == NULL)
    return NULL;

  // find the target hole according to the chosen algorithm
  int target_hole = find_target_hole(size);

  // if no hole is found, return NULL
  if (target_hole == -1)
    return NULL;

  if (list[target_hole].size == size)
  {
    list[target_hole].in_use = 1;
    list[target_hole].type = P;
    return list[target_hole].arena;
  }

  // if the hole is bigger than the size, split the hole
  list[free_node].size = list[target_hole].size - size;
  list[target_hole].size = size;

  list[target_hole].in_use = 1;
  list[target_hole].type = P;

  list[free_node].next = list[target_hole].next;
  list[target_hole].next = free_node;

  list[free_node].in_use = 1;
  list[free_node].type = H;
  list[free_node].arena = list[target_hole].arena + size;
  list[free_node].previous = target_hole;

  linked_list_size++;

  return list[target_hole].arena;
}

void mavalloc_free(void *ptr)
{
  if (ptr == NULL)
    return;

  int target_node = -1;
  for (int i = 0; i != -1; i = list[i].next)
  {
    if (list[i].arena == ptr && list[i].in_use && list[i].type == P)
    {
      target_node = i;
      break;
    }
  }

  if (target_node == -1)
    return;

  // check for the corner cases  firs
  // if the target node is the first node in the list
  list[target_node].in_use = 1;
  list[target_node].type = H;

  int next_node = list[target_node].next;
  int previous_node = list[target_node].previous;

  // merge the list with the next node if it is a hole
  if (next_node != -1 && list[next_node].type == H)
  {
    list[target_node].size += list[next_node].size;
    list[target_node].next = list[next_node].next;

    list[next_node].in_use = 0;

    next_node = list[target_node].next;

    if (next_node != -1)
      list[next_node].previous = target_node;

    linked_list_size--;
  }

  // merge the list with the previous node if it is a hole
  if (previous_node != -1 && list[previous_node].type == H)
  {
    list[previous_node].size += list[target_node].size;
    list[previous_node].next = list[target_node].next;

    list[target_node].in_use = 0;
    next_node = list[previous_node].next;

    if (next_node != -1)
      list[next_node].previous = previous_node;

    linked_list_size--;
  }
}

int mavalloc_size()
{
  return linked_list_size;
}
