#include "mavalloc.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

// benchmark with FIRST FIT algorithm

// code to measure time taken by a function
// inspired from https://stackoverflow.com/questions/10192903/time-in-milliseconds-in-c
struct timeval t0;
struct timeval t1;
float timedifference_msec(struct timeval t0, struct timeval t1)
{
  return (t1.tv_sec - t0.tv_sec) * 1000.0f + (t1.tv_usec - t0.tv_usec) / 1000.0f;
}

float toal_time = 0;
float penalty_per_null = .05;
void test1()
{

  float penalty = 0;
 
  gettimeofday(&t0, 0);
  mavalloc_init(1000000, FIRST_FIT);  

  mavalloc_free(NULL);
  int x=10;
  mavalloc_free(&x);
  void *p =mavalloc_alloc(10000100);
  mavalloc_free(p);

  int *ptr[10];
  int value[] = {10000, 2000, 2020, 1100, 100, 13000, 14000, 1900, 200, 1000};

  ptr[0] = mavalloc_alloc(value[0]);if(ptr[0] == NULL)penalty += penalty_per_null;
  

  ptr[1] = mavalloc_alloc(value[1]);if(ptr[1] == NULL)penalty += penalty_per_null;
  ptr[2] = mavalloc_alloc(value[2]);if(ptr[2] == NULL)penalty += penalty_per_null;

  mavalloc_free(ptr[0]);
  mavalloc_free(ptr[1]);

  ptr[3] = mavalloc_alloc(value[3]);if(ptr[3] == NULL)penalty += penalty_per_null;
  ptr[4] = mavalloc_alloc(value[4]);if(ptr[4] == NULL)penalty += penalty_per_null;
  ptr[5] = mavalloc_alloc(value[5]);if(ptr[5] == NULL)penalty += penalty_per_null;

  ptr[6] = mavalloc_alloc(value[6]);if(ptr[6] == NULL)penalty += penalty_per_null;

  mavalloc_free(ptr[5]);

  ptr[7] = mavalloc_alloc(value[7]);if(ptr[7] == NULL)penalty += penalty_per_null;

  mavalloc_free(ptr[6]);

  ptr[8] = mavalloc_alloc(value[8]);if(ptr[8] == NULL)penalty += penalty_per_null;
  mavalloc_free(ptr[2]);
  mavalloc_free(ptr[4]);
  mavalloc_free(ptr[7]);

  ptr[9] = mavalloc_alloc(value[9]);if(ptr[9] == NULL)penalty += penalty_per_null;

  mavalloc_free(ptr[3]);

  mavalloc_free(ptr[8]);
  mavalloc_free(ptr[9]);
  mavalloc_destroy();

  gettimeofday(&t1, 0);
  float elapsed = timedifference_msec(t0, t1);
  toal_time += elapsed+penalty;
  printf("Test1: %.3f ms\n", elapsed+penalty);
}

void test2()
{

  float penalty = 0;

  gettimeofday(&t0, 0);
  mavalloc_init(65000, FIRST_FIT);  
  int *ptr[11];
  int value[] = {13000, 14000, 2020, 10000, 2000, 1100, 100, 1900, 200, 100000, 1233};

  ptr[0] = mavalloc_alloc(value[0]);if(ptr[0] == NULL)penalty += penalty_per_null;
  ptr[1] = mavalloc_alloc(value[1]);if(ptr[1] == NULL)penalty += penalty_per_null;
  mavalloc_free(ptr[0]);
  ptr[2] = mavalloc_alloc(value[2]);if(ptr[2] == NULL)penalty += penalty_per_null;

  mavalloc_free(ptr[1]);

  ptr[3] = mavalloc_alloc(value[3]);if(ptr[3] == NULL)penalty += penalty_per_null;
  ptr[4] = mavalloc_alloc(value[4]);if(ptr[4] == NULL)penalty += penalty_per_null;
  ptr[5] = mavalloc_alloc(value[5]);if(ptr[5] == NULL)penalty += penalty_per_null;

  ptr[6] = mavalloc_alloc(value[6]);if(ptr[6] == NULL)penalty += penalty_per_null;

  mavalloc_free(ptr[5]);

  ptr[7] = mavalloc_alloc(value[7]);if(ptr[7] == NULL)penalty += penalty_per_null;

  mavalloc_free(ptr[6]);

  ptr[8] = mavalloc_alloc(value[8]);if(ptr[8] == NULL)penalty += penalty_per_null;
  mavalloc_free(ptr[2]);

  mavalloc_free(ptr[7]);

  ptr[9] = mavalloc_alloc(value[9]);if(ptr[9] == NULL)penalty += penalty_per_null;

  mavalloc_free(ptr[3]);
  mavalloc_free(ptr[4]);

  ptr[10] = mavalloc_alloc(value[10]);if(ptr[10] == NULL)penalty += penalty_per_null;

  mavalloc_free(ptr[8]);
  mavalloc_free(ptr[9]);
  mavalloc_free(ptr[10]);
  mavalloc_destroy();
  gettimeofday(&t1, 0);
 
  float elapsed = timedifference_msec(t0, t1);
  toal_time += elapsed+penalty;
  printf("Test2: %.3f ms\n", elapsed+penalty);
}

void test3()
{

  float penalty = 0;

  gettimeofday(&t0, 0);
  mavalloc_init(45500, FIRST_FIT);  

  int *ptr[10];
  int value[] = {10000, 2000, 2020, 1100, 100, 13000, 14000, 19000, 2000, 1000};

  ptr[0] = mavalloc_alloc(value[0]);if(ptr[0] == NULL)penalty += penalty_per_null;
  ptr[1] = mavalloc_alloc(value[1]);if(ptr[1] == NULL)penalty += penalty_per_null;
  ptr[2] = mavalloc_alloc(value[2]);if(ptr[2] == NULL)penalty += penalty_per_null;
  ptr[3] = mavalloc_alloc(value[3]);if(ptr[3] == NULL)penalty += penalty_per_null;
  ptr[4] = mavalloc_alloc(value[4]);if(ptr[4] == NULL)penalty += penalty_per_null;
  ptr[5] = mavalloc_alloc(value[5]);if(ptr[5] == NULL)penalty += penalty_per_null;

  mavalloc_free(ptr[1]);

  ptr[6] = mavalloc_alloc(value[6]);if(ptr[6] == NULL)penalty += penalty_per_null;

  mavalloc_free(ptr[5]);

  ptr[7] = mavalloc_alloc(value[7]);if(ptr[7] == NULL)penalty += penalty_per_null;

  mavalloc_free(ptr[6]);
  mavalloc_free(ptr[0]);
  ptr[8] = mavalloc_alloc(value[8]);if(ptr[8] == NULL)penalty += penalty_per_null;
  mavalloc_free(ptr[2]);
  mavalloc_free(ptr[4]);
  mavalloc_free(ptr[7]);

  ptr[9] = mavalloc_alloc(value[9]);if(ptr[9] == NULL)penalty += penalty_per_null;

  mavalloc_free(ptr[3]);

  mavalloc_free(ptr[8]);
  mavalloc_free(ptr[9]);

  mavalloc_destroy();
  gettimeofday(&t1, 0);

  float elapsed = timedifference_msec(t0, t1);
  toal_time += elapsed+penalty;
  printf("Test3: %.3f ms\n", elapsed+penalty);
}

int main(int argc, char *argv[])
{

  puts("FIRST_FIT");
  test1();
  test2();
  test3();
  printf("Total time: %.3f ms\n", toal_time);

  return 0;
}
