#include "mavalloc.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

// benchmark with system malloc and free

// code to measure time taken by a function
// inspired from https://stackoverflow.com/questions/10192903/time-in-milliseconds-in-c
struct timeval t0;
struct timeval t1;
float timedifference_msec(struct timeval t0, struct timeval t1)
{
  return (t1.tv_sec - t0.tv_sec) * 1000.0f + (t1.tv_usec - t0.tv_usec) / 1000.0f;
}

float toal_time = 0;

void test1()
{

  gettimeofday(&t0, 0);
  free(NULL);
  void *p = malloc(10000100);
  free(p);

  int *ptr[10];
  int value[] = {10000, 2000, 2020, 1100, 100, 13000, 14000, 1900, 200, 1000};

  ptr[0] = malloc(value[0]);
  ptr[1] = malloc(value[1]);
  ptr[2] = malloc(value[2]);

  free(ptr[0]);
  free(ptr[1]);

  ptr[3] = malloc(value[3]);
  ptr[4] = malloc(value[4]);
  ptr[5] = malloc(value[5]);

  ptr[6] = malloc(value[6]);

  free(ptr[5]);

  ptr[7] = malloc(value[7]);

  free(ptr[6]);

  ptr[8] = malloc(value[8]);
  free(ptr[2]);
  free(ptr[4]);
  free(ptr[7]);

  ptr[9] = malloc(value[9]);

  free(ptr[3]);

  free(ptr[8]);
  free(ptr[9]);

  gettimeofday(&t1, 0);
  float elapsed = timedifference_msec(t0, t1);
  toal_time += elapsed;
  printf("Test1: %.3f ms\n", elapsed);
}

void test2()
{

  gettimeofday(&t0, 0);

  int *ptr[11];
  int value[] = {13000, 14000, 2020, 10000, 2000, 1100, 100, 1900, 200, 1000, 1233};

  ptr[0] = malloc(value[0]);
  ptr[1] = malloc(value[1]);
  free(ptr[0]);
  ptr[2] = malloc(value[2]);

  free(ptr[1]);

  ptr[3] = malloc(value[3]);
  ptr[4] = malloc(value[4]);
  ptr[5] = malloc(value[5]);

  ptr[6] = malloc(value[6]);

  free(ptr[5]);

  ptr[7] = malloc(value[7]);

  free(ptr[6]);

  ptr[8] = malloc(value[8]);
  free(ptr[2]);

  free(ptr[7]);

  ptr[9] = malloc(value[9]);

  free(ptr[3]);
  free(ptr[4]);

  ptr[10] = malloc(value[10]);

  free(ptr[8]);
  free(ptr[9]);
  free(ptr[10]);

  gettimeofday(&t1, 0);
  float elapsed = timedifference_msec(t0, t1);
  toal_time += elapsed;
  printf("Test2: %.3f ms\n", elapsed);
}

void test3()
{

  gettimeofday(&t0, 0);


  int *ptr[11];
  int value[] = {13000, 14000, 2020, 10000, 2000, 1100, 100, 1900, 200, 100000, 1233};
  
  ptr[0] = malloc(value[0]);
  ptr[1] = malloc(value[1]);
  ptr[2] = malloc(value[2]);
  ptr[3] = malloc(value[3]);
  ptr[4] = malloc(value[4]);
  ptr[5] = malloc(value[5]);

  free(ptr[1]);

  ptr[6] = malloc(value[6]);

  free(ptr[5]);

  ptr[7] = malloc(value[7]);

  free(ptr[6]);
  free(ptr[0]);
  ptr[8] = malloc(value[8]);
  free(ptr[2]);
  free(ptr[4]);
  free(ptr[7]);

  ptr[9] = malloc(value[9]);

  free(ptr[3]);

  free(ptr[8]);
  free(ptr[9]);

  gettimeofday(&t1, 0);
  float elapsed = timedifference_msec(t0, t1);
  toal_time += elapsed;
  printf("Test3: %.3f ms\n", elapsed);
}

int main(int argc, char *argv[])
{

  puts("SYSTEM_MALLOC");
  test1();
  test2();
  test3();
  printf("Total time: %.3f ms\n", toal_time);

  return 0;
}
